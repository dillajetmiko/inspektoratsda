<!DOCTYPE html>
<html>
<head>
    <title>kop surat</title>
	<style>
                .calibri
                {
                    font-family: calibri;
                }
    </style>
</head>

<h class="calibri">
	<table align="center" >

	<tr>
    <td><img src="{{ asset('asset/dist/img/sda.png')}}" width="100" height="100"></td>
    <td><center>
		<font size="5"><b>PEMERINTAH KABUPATEN SIDOARJO</b></font><BR>
        <font size="6"><b>INSPEKTORAT DAERAH</b></font><BR>
        <font size="3"><i>Jl. Untung Suropati Nomor 10</i></font><BR>
        <font size="3"><i>Telepon.(031) 8948163 ; Fax. (031) 99010187</i></font><BR>
        <font size="3"><i>Email : inspektorat@sidoarjokab.go.id Website : inspektorat.sidoarjokab.go.id</i></font><BR>
    </td>
	</tr>
			
	<tr>
		<td colspan="3"><hr size="2"> </td>
	</tr>
	</table>

	<br>

	<table align="center" >
	<tr>
    <td><center>
		<font size="4"><b><u>SURAT TUGAS</u></b></font><BR>
		<font size="4">Nomor : 700/264/438.4/2021</font><BR>
    </td>
	</tr>	
	</table>

	<br>

	<table align="center" >
	<tr>
    <td>
		<font size="4">Dasar &emsp; &emsp;&emsp; &emsp;:&ensp;Surat Pengaduan Masyarakat an. RENITA</font><BR>
    </td>
	</tr>
	</table>

	<br>

	<table align="center" >
	<tr>
    <td><center>
		<font size="4"><b>MENUGASKAN :</b></font><BR>
    </td>
	</tr>	
	</table>

	<table align="center" >
	<tr>
    <td>
	<table>
        <tr>
            <td valign="top">
			<br>	
			<font size="4"> Kepada &ensp;&ensp; &emsp;</font>
			</td>
            <td valign="top">
			<font size="4"><ol> <li>ANDJAR SURJADIANTO, S.Sos.</li>
			<li>Drs. MOCH. SOLICHIN</li>
			<li>Dra. LAELY WIDJAJATI, M.Si.</li>
			<li>HARI SUNDJAJA, S.Sos</li>
			<li>AMIK MARIANA, SE.</li>
			<li>DIAH ERNI YULIANSYAH, SE</li>
			<li>METTAVIANY PRIMALIA L, A.Md</li>
			<li>NABILLAH CITRA CHAESARI, A.Md</li></ol>
			</td>
			<td valign="top">
			<br>	
			<font size="4"> &ensp;&ensp; </font>
			</td>
			<td valign="top">
			<br>
			<font size="4">Penanggungjawab<br>
			Pembantu Penanggungjawab<br>
			Pengendali Mutu<br>
			Pengendali Teknis<br>
			Ketua Tim<br>
			Anggota<br>
			Anggota<br>
			Anggota<br>
			</td>
        </tr>
    </table>
    </td>
	</tr>
	</table>

	<table align="center" >
	<tr>
    <td>
		<font size="4">
		<p align="justify">Untuk melaksanakan Klarifikasi atas pengaduan masyarakat tentang pelayanan Pendaftaran Tanah Sistematis Lengkap (PTSL) di Desa Jatikalang Kecamatan Krian Kabupaten Sidoarjo.</P>	
		<p align="justify">Jangka waktu klarifikasi selama 8 (delapan) hari kerja pada periode tanggal 26 Januari s.d 4 Februari 2021.</p>
		<p align="justify">Kepada pihak-pihak yang bersangkutan diminta kesediaannya untuk memberikan bantuan serta keterangan-keterangan yang diperlukan guna kelancaran dalam penyelesaian tugas yang dimaksud.</p>
		<p align="justify"></p>
		</font><BR>
    </td>
	</tr>
	</table>

	<br>

		<table align="right" >
	<tr>
    <td align="left">
		<font size="4">Sidoarjo, 22 Januari 2021</font><BR>
		<font size="4"><b>INSPEKTUR KABUPATEN SIDOARJO</b></font><BR>
	</td>
	</tr>	
	</table>
	<br>
	<br>
	<br>
	<table align="right" >
	<tr>
    <td align="left">
	<img src="{{ asset('asset/dist/img/ttd.jpeg')}}" width="260" height="80">
    </td>
	</tr>	
	</table>
	<br>
	<br>
	<br>
	<br>
	<br>
	<table align="right" >
	<tr>
    <td align="left">
		<font size="4"><b><u>ANDJAR SURJADIANTO, S.Sos.</u></b></font><BR>
		<font size="4">Pembina Utama Muda</font><BR>
		<font size="4">NIP.19700926 199003 1 005</font><BR>
    </td>
	</tr>	
	</table>

		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<!-- <br>
		<br>
		<br> -->

		<table align="center" >
	<tr>
    <td align="left"><img src="{{ asset('asset/dist/img/balai.png')}}" width="108" height="60"></td>
	<td valign="center">
    <td><center>
		<font size="1">
			<p style="line-height: 10px;">
			Dokumen ini telah ditandatangani secara elektronik menggunakan sertifikat elektronik yang diterbitkan oleh BSrE sesuai dengan Undang Undang No 11 Tahun 2008 tentang Informasi dan Transaksi Elektronik, tandatangan secara elektronik memiliki kekuatan hukum dan akibat hukum yang sah.
			</p>
		</font>
    </td>
	</tr>
	</table>
</h>
</html>