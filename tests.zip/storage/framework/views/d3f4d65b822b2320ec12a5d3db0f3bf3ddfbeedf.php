

<?php $__env->startSection('page_title', 'Inspektorat || Edit Temuan'); ?>

<?php $__env->startSection('title', 'Data Temuan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/temuan">Temuan</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>  
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Title</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/temuan/update_temuan" method="post">
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
			</select><br>
			Kode Temuan : <input type="text" class="form-control" name="KODE_TEMUAN" value="<?php echo e($temuan[0]->KODE_TEMUAN); ?>" readonly><br>

            Nomor LHP : 
                <select class="form-control select2" name="NOMOR_LHP">
                <?php $__currentLoopData = $id2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LHP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($LHP->NOMOR_LHP === $temuan[0]->NOMOR_LHP): ?>
                <option value="<?php echo e($LHP->NOMOR_LHP); ?>" selected><?php echo e($LHP->NOMOR_LHP); ?></option>
                <?php else: ?>
                <option value="<?php echo e($LHP->NOMOR_LHP); ?>"><?php echo e($LHP->NOMOR_LHP); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>

            Uraian Temuan : <input type="text" class="form-control" name="URAIAN_TEMUAN" value="<?php echo e($temuan[0]->URAIAN_TEMUAN); ?>"><br>
            Kode Rekomendasi : <input type="text" class="form-control" name="KODE_REKOMENDASI" value="<?php echo e($temuan[0]->KODE_REKOMENDASI); ?>"><br>
            Uraian Rekomendasi : <input type="text" class="form-control" name="URAIAN_REKOMENDASI" value="<?php echo e($temuan[0]->URAIAN_REKOMENDASI); ?>"><br>
            Uraian Tindak Lanjut : <input type="text" class="form-control" name="URAIAN_TINDAK_LANJUT" value="<?php echo e($temuan[0]->URAIAN_TINDAK_LANJUT); ?>"><br>
            
            Status  : <br>
                <?php if($temuan[0]->KODE_STATUS == 1): ?> 
                <label><input type="radio" name="KODE_STATUS" value="1" checked="checked"/> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="KODE_STATUS" value="2" /> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="KODE_STATUS" value="3" /> Sesuai Rekomendasi </label><br>
                <?php elseif($temuan[0]->KODE_STATUS == 2): ?>
                <label><input type="radio" name="KODE_STATUS" value="1" /> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="KODE_STATUS" value="2" checked="checked"/> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="KODE_STATUS" value="3" /> Sesuai Rekomendasi </label><br>
                <?php elseif($temuan[0]->KODE_STATUS == 3): ?>
                <label><input type="radio" name="KODE_STATUS" value="1" /> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="KODE_STATUS" value="2" /> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="KODE_STATUS" value="3" checked="checked"/> Sesuai Rekomendasi </label><br>
                <?php endif; ?>
                <br>
            
            Nama Pejabat :<input type="text" class="form-control" name="NAMA_PEJABAT" value="<?php echo e($temuan[0]->NAMA_PEJABAT); ?>"><br> 
            Jabatan Pejabat :<input type="text" class="form-control" name="JABATAN_PEJABAT" value="<?php echo e($temuan[0]->JABATAN_PEJABAT); ?>"><br> 
            NIP Pejabat :<input type="text" class="form-control" name="NIP_PEJABAT" value="<?php echo e($temuan[0]->NIP_PEJABAT); ?>"><br> 
            
          		
            Tanggal Temuan : <input type="date" class="form-control" name="TANGGAL_TEMUAN" value="<?php echo e($temuan[0]->TANGGAL_TEMUAN); ?>"><br>
            Tanggal Tindak Lanjut : <input type="date" class="form-control" name="TANGGAL_TINDAK_LANJUT" value="<?php echo e($temuan[0]->TANGGAL_TINDAK_LANJUT); ?>"><br>
        	Kerugian: <input type="text" class="form-control" name="KERUGIAN" value="<?php echo e($temuan[0]->KERUGIAN); ?>"><br>

            Jenis Temuan : 
                <select class="form-control" name="KODE_JENIS_TEMUAN">
                    <?php $__currentLoopData = $id3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JENIS_TEMUAN): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($JENIS_TEMUAN->KODE_JENIS_TEMUAN === $temuan[0]->KODE_JENIS_TEMUAN): ?>
                    <option value="<?php echo e($JENIS_TEMUAN->KODE_JENIS_TEMUAN); ?>" selected><?php echo e($JENIS_TEMUAN->NAMA_JENIS_TEMUAN); ?></option>
                    <?php else: ?> 
                    <option value="<?php echo e($JENIS_TEMUAN->KODE_JENIS_TEMUAN); ?>"><?php echo e($JENIS_TEMUAN->NAMA_JENIS_TEMUAN); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <br>

            Hasil Telaah : <input type="text" class="form-control" name="HASIL_TELAAH" value="<?php echo e($temuan[0]->HASIL_TELAAH); ?>"><br>	
            <button type="submit" class="btn btn-primary">Update</button>
			</form>
	</div>
	<!-- /.card-body -->
	<div class="card-footer">
	
	</div>
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset ('asset/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
  $(function () {

    //Initialize Select2 Elements
    $('.select2').select2()

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/temuan/edit_temuan.blade.php ENDPATH**/ ?>