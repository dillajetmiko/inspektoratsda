
<?php $__env->startSection("page_title","Inspektorat || Tambah LHP"); ?>
<?php $__env->startSection("title","Data LHP"); ?>

<?php $__env->startSection("breadcrumb"); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/lhp">LHP</a></li>
<li class="breadcrumb-item active">Tambah LHP</li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>  
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Default box -->
 <div class="card">    
    <div class="card-header">
        <h3 class="card-title">Tambah LHP</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
        </div>
    </div>
    <div class="card-body">
    <!-- <h1>Tambah Data Temuan</h1> -->
      <form action="/lhp/tambah_lhp" method="post" enctype="multipart/form-data">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
        Nomor LHP : <input type="text" class="form-control" name="NOMOR_LHP"><br>
        NOMOR SPT : 
            <select class="form-control select2" name="ID_SPT">
            <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($spt->id); ?>"><?php echo e($spt->NOMOR_SPT); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
        Tanggal LHP : <input type="date" class="form-control" name="TANGGAL_LHP"><br>
        Judul Pemeriksaan : <input type="text" class="form-control" name="JUDUL_PEMERIKSAAN"><br>
        Anggaran : <input type="text" class="form-control" name="ANGGARAN"><br>

        Upload file : 
        <!-- <div class="form-group">
          <label for="exampleInputFile">File input</label>
          <div class="input-group">
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="file">
              <label class="custom-file-label" for="file">Choose file</label>
            </div>
            <div class="input-group-append">
              <span class="input-group-text" id="submit">Upload</span>
            </div>
          </div>
        </div> -->

        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">File <span class="required">*</span></label>
          <!-- <div class="col-md-6 col-sm-6 col-xs-12"> -->

            <input type='file' name='file' class="form-control">

            <!-- <?php if($errors->has('file')): ?>
              <span class="errormsg text-danger"><?php echo e($errors->first('file')); ?></span>
            <?php endif; ?> -->
          <!-- </div> -->
        </div>
        <br> 
        <button type="submit" class="btn btn-primary">Simpan</button>

      </form>

    </div>
    <!-- /.card-body -->

    <div class="card-footer">

    </div>
    <!-- /.card-footer-->
  <!-- </div> -->
  <!-- </div> -->
  <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset ('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.mainlayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/LHP/insert_lhp.blade.php ENDPATH**/ ?>