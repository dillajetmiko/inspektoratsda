<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
</style>
<table>
				<?php $__currentLoopData = $lhp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datalhp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Judul Pemeriksaan</th>
					<td>: <?php echo e($datalhp->JUDUL_PEMERIKSAAN); ?></td>
				</tr>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Tanggal LHP</th>
					<td>: <?php echo e($datalhp->TANGGAL_LHP); ?></td>
				</tr>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Nomor LHP</th>
					<td>: <?php echo e($datalhp->NOMOR_LHP); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>

<table id="example1" class="table table-bordered table-striped">
				<thead style="background-color: lightgrey; color: blue;">
				<tr>		
                    <th colspan="2" scope="colgroup" style="font-weight: bold; text-align:center">Temuan</th>
                    <th colspan="2" scope="colgroup" style="font-weight: bold; text-align:center">Rekomendasi</th>
                    <th colspan="2" scope="colgroup" style="font-weight: bold; text-align:center">Tindak Lanjut</th>
                    <th rowspan="2" scope="rowgroup" style="font-weight: bold; text-align:center; width: 20px">Tanggal Tindak Lanjut</th>
                    <th rowspan="2" scope="rowgroup" style="font-weight: bold; text-align:center; width: 15px">Kerugian</th>
                    <th rowspan="2" scope="rowgroup" style="font-weight: bold; text-align:center; width: 25px">Nama OPD</th>
                </tr>
                <tr>
                    <th style="font-weight: bold; text-align:center">Kode</th>
                    <th style="font-weight: bold; text-align:center; width: 25px">Uraian</th>
                    <th style="font-weight: bold; text-align:center">Kode</th>
                    <th style="font-weight: bold; text-align:center; width: 25px">Uraian</th>
                    <th style="font-weight: bold; text-align:center; width: 25px">Uraian</th>
                    <th style="font-weight: bold; text-align:center; width: 15px">Status</th>
                </tr>
				</thead>
				<tbody>		
				<?php $__currentLoopData = $cetak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($data->KODE_TEMUAN); ?></td>
						<td><?php echo e($data->URAIAN_TEMUAN); ?></td>
						<td><?php echo e($data->KODE_REKOMENDASI); ?></td>
						<td><?php echo e($data->URAIAN_REKOMENDASI); ?></td>
						<td><?php echo e($data->URAIAN_TINDAK_LANJUT); ?></td>
						<?php if($data->KODE_STATUS == 1): ?>
						<td> Belum Ditindak Lanjut</td>
						<?php elseif($data->KODE_STATUS == 2): ?>
						<td> Belum Sesuai Rekomendasi</td>
						<?php elseif($data->KODE_STATUS == 3): ?>
						<td> Sesuai Rekomendasi</td>
						<?php endif; ?>
						<td><?php echo e($data->TANGGAL_TINDAK_LANJUT); ?></td>
						<td><?php echo e($data->KERUGIAN); ?></td>
						<td>
						<?php $__currentLoopData = $punya_opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OPD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($OPD->KODE_TEMUAN === $data->KODE_TEMUAN): ?>
								<?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($opd->KODE_OPD === $OPD->KODE_OPD): ?>
								<?php echo e($opd->NAMA_OPD); ?><br>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<tfoot>
				<!-- <tr>
				<th>NIS_NIP</th>
				<th>nama_anggota</th>
				<th>tahun_masuk</th>
				<th>kelas</th>
				<th>username_anggota</th>
				<th>password_anggota</th>
				</tr> -->
				</tfoot>
			</table><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/cetak/cetak_view.blade.php ENDPATH**/ ?>