

<?php $__env->startSection('page_title', 'Inspektorat | Home'); ?>

<?php $__env->startSection('custom_css'); ?>
<style>
.center {
  text-align: center;
  border: 3px solid green;
}
.container {
  display: flex;
  justify-content: center;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Inspektorat Sidoarjo'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Home</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Small boxes (Stat box) -->
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-menu')): ?>
<div class="container">
	<div class="col-lg-4 col-6">
		<!-- small box -->
		<div class="small-box bg-info">
			<div class="inner">
				<h3>Form LHP</h3>

			</div>
			<div class="icon">
				<i class="ion ion-document-text"></i>
			</div>
			<a href="/lhp/insert_lhp" class="small-box-footer">Input <i class="fas fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
	<div class="col-lg-4 col-6">
		<!-- small box -->
		<div class="small-box bg-success">
			<div class="inner">
				<h3>Form Temuan</sup></h3>

			</div>
			<div class="icon">
				<i class="ion ion-search"></i>
			</div>
			<a href="/temuan/insert_temuan" class="small-box-footer">Input <i class="fas fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
</div>
<?php else: ?>
anda belum punya role
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/dashboard.blade.php ENDPATH**/ ?>