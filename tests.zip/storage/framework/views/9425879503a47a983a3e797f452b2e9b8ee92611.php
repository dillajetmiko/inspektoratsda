
<?php $__env->startSection("page_title","Inspektorat || Tambah Pegawai"); ?>
<?php $__env->startSection("title","Data Pegawai"); ?>

<?php $__env->startSection("breadcrumb"); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/lhp">Pegawai</a></li>
<li class="breadcrumb-item active">Tambah Pegawai</li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>  
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Default box -->
 <div class="card">    
    <div class="card-header">
        <h3 class="card-title">Tambah Pegawai</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
        </div>
    </div>
    <div class="card-body">
    <!-- <h1>Tambah Data Temuan</h1> -->
      <form action="/pegawai/tambah_pegawai" method="post" enctype="multipart/form-data">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
        NIK : <input type="text" class="form-control" name="NIK_PEGAWAI"><br>
        Nama : <input type="text" class="form-control" name="NAMA_PEGAWAI"><br>
        Alamat : <input type="text" class="form-control" name="ALAMAT_PEGAWAI"><br>
        Tempat Tanggal Lahir : <input type="text" class="form-control" name="TTL_PEGAWAI"><br>
        NIP : <input type="text" class="form-control" name="NIP_PEGAWAI"><br>
        No. kartu Pegawai : <input type="text" class="form-control" name="NO_KARTU_PEGAWAI"><br>
        No. kartu Suami/Istri : <input type="text" class="form-control" name="NO_KARTU_SUAMI_ISTRI"><br>
        No. Taspen : <input type="text" class="form-control" name="NO_TASPEN"><br>
        No. HP : <input type="text" class="form-control" name="NO_HP"><br>
        Keluarga : <input type="text" class="form-control" name="KELUARGA"><br>
        Unit Kerja : <input type="text" class="form-control" name="UNIT_KERJA_PEGAWAI"><br>
        <br> 
        <button type="submit" class="btn btn-primary">Simpan</button>

      </form>

    </div>
    <!-- /.card-body -->

    <div class="card-footer">

    </div>
    <!-- /.card-footer-->
  <!-- </div> -->
  <!-- </div> -->
  <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset ('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.mainlayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/pegawai/insert_pegawai.blade.php ENDPATH**/ ?>