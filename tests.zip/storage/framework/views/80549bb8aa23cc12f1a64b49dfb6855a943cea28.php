
<?php $__env->startSection("page_title","Inspektorat || Tambah Data Temuan"); ?>
<?php $__env->startSection("title","Data Temuan"); ?>

<?php $__env->startSection("breadcrumb"); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/temuan">Temuan</a></li>
<li class="breadcrumb-item active">Tambah Temuan</li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>  
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <!-- Default box -->
 <div class="card">    
    <div class="card-header">
        <h3 class="card-title">Tambah Data Temuan</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i></button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fas fa-times"></i></button>
        </div>
    </div>
    <div class="card-body">
    <!-- <h1>Tambah Data Temuan</h1> -->
      
        <form action="/temuan/tambah_temuan" method="post">
        <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
        Kode Temuan : <input type="text" class="form-control" name="KODE_TEMUAN"><br>
        
        No LHP : 
            <select class="form-control select2" name="NOMOR_LHP">
            <?php $__currentLoopData = $id2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($lhp->NOMOR_LHP); ?>"><?php echo e($lhp->NOMOR_LHP); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>

        Uraian Temuan : <input type="text" class="form-control" name="URAIAN_TEMUAN"><br>
        Kode Rekomendasi : <input type="text" class="form-control" name="KODE_REKOMENDASI"><br>
        Uraian Rekomendasi : <input type="text" class="form-control" name="URAIAN_REKOMENDASI"><br>
        Uraian Tindak Lanjut : <input type="text" class="form-control" name="URAIAN_TINDAK_LANJUT"><br>
        Status Tindak Lanjut :<br> 
            <label><input type="radio" name="KODE_STATUS" value="1" checked="checked" /> Belum Ditindak Lanjut </label><br>
            <label><input type="radio" name="KODE_STATUS" value="2" /> Belum Sesuai Rekomendasi </label><br>
            <label><input type="radio" name="KODE_STATUS" value="3" /> Sesuai rekomendasi </label><br><br>
        <!-- Jenis Pengawasan : <input type="text" class="form-control" name="JENIS_PENGAWASAN"><br> -->

        <!-- Nama OPD : 
            <select class="form-control select2" name="KODE_OPD">
            <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($opd->KODE_OPD); ?>"><?php echo e($opd->NAMA_OPD); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br> -->
        Nama Pejabat : <input type="text" class="form-control" name="NAMA_PEJABAT"><br>
        Jabatan : <input type="text" class="form-control" name="JABATAN_PEJABAT"><br>
        NIP : <input type="text" class="form-control" name="NIP_PEJABAT"><br>
        Tanggal Temuan : <input type="date" class="form-control" name="TANGGAL_TEMUAN"><br>
        Tanggal Tindak Lanjut : <input type="date" class="form-control" name="TANGGAL_TINDAK_LANJUT"><br>
        Kerugian : <input type="text" class="form-control" name="KERUGIAN"><br>
        Jenis Temuan : 
            <select class="form-control" name="KODE_JENIS_TEMUAN">
            <option value="1">Internal</option>
            <option value="2">Eksternal</option>
            </select><br>
        Hasil Telaah Tindak Lanjut: <input type="text" class="form-control" name="HASIL_TELAAH"><br>
        <button type="submit" class="btn btn-primary">Simpan</button>
        </form>

    </div>
    <!-- /.card-body -->

    <div class="card-footer">

    </div>
    <!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset ('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset ('asset/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });

    //Initialize Select2 Elements
    $('.select2').select2()

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.mainlayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/temuan/insert_temuan.blade.php ENDPATH**/ ?>