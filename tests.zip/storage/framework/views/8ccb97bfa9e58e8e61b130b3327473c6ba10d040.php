

<?php $__env->startSection('page_title', 'Inspektorat || Edit USER'); ?>

<?php $__env->startSection('title', 'Data USER'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/user">USER</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Data User</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/user/update_user" method="post">  
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

			</select><br>
			NIP : <input type="text" class="form-control" name="NIP" value="<?php echo e($user[0]->NIP); ?>" readonly><br>
            Nama : <input type="text" class="form-control" name="NAMA" value="<?php echo e($user[0]->name); ?>"><br>
			Email : <input type="text" class="form-control" name="EMAIL" value="<?php echo e($user[0]->email); ?>"><br>
            Password : <input type="password" class="form-control" name="PASSWORD" placeholder="isi jika merubah password"><br>
			Role :<br>
				<?php if($user[0]->id_role == 1): ?> 
                <label><input type="radio" name="id_role" value="1" checked="checked"/> Admin </label><br>
                <label><input type="radio" name="id_role" value="2" /> User </label><br>
                <label><input type="radio" name="id_role" value="3" /> Super Admin </label><br>
                <?php elseif($user[0]->id_role == 2): ?>
                <label><input type="radio" name="id_role" value="1" /> Admin </label><br>
                <label><input type="radio" name="id_role" value="2" checked="checked"/> User </label><br>
                <label><input type="radio" name="id_role" value="3" /> Super Admin </label><br>
                <?php elseif($user[0]->id_role == 3): ?>
                <label><input type="radio" name="id_role" value="1" /> Admin </label><br>
                <label><input type="radio" name="id_role" value="2" /> User </label><br>
                <label><input type="radio" name="id_role" value="3" checked="checked"/> Super Admin </label><br>
				<?php else: ?>
				<label><input type="radio" name="id_role" value="1" /> Admin </label><br>
                <label><input type="radio" name="id_role" value="2" /> User </label><br>
                <label><input type="radio" name="id_role" value="3" /> Super Admin </label><br>
                <?php endif; ?>
                <br>
			Jabatan: <input type="text" class="form-control" name="JABATAN" value="<?php echo e($user[0]->jabatan); ?>"><br>
            Pangkat: <input type="text" class="form-control" name="PANGKAT" value="<?php echo e($user[0]->pangkat); ?>"><br>
            
        <br><br>
        <button type="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
	<!-- /.card-body -->
	
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/user/edit_user.blade.php ENDPATH**/ ?>