

<?php $__env->startSection('page_title', 'Inspektorat || Edit LHP'); ?>

<?php $__env->startSection('title', 'Data LHP'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/lhp">LHP</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Data LHP</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/lhp/update_lhp" method="post" enctype="multipart/form-data">  
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

			</select><br>
			Nomor LHP : <input type="text" class="form-control" name="NOMOR_LHP" value="<?php echo e($lhp[0]->NOMOR_LHP); ?>" readonly><br>
			Nomor SPT: 
                <select class="form-control select2" name="ID_SPT">
                <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SPT): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($SPT->id === $lhp[0]->ID_SPT): ?>
                <option value="<?php echo e($SPT->id); ?>" selected><?php echo e($SPT->NOMOR_SPT); ?></option>
                <?php else: ?>
                <option value="<?php echo e($SPT->id); ?>"><?php echo e($SPT->NOMOR_SPT); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
            Tanggal : <input type="date" class="form-control" name="TANGGAL_LHP" value="<?php echo e($lhp[0]->TANGGAL_LHP); ?>"><br>
            Judul Pemeriksaan : <input type="text" class="form-control" name="JUDUL_PEMERIKSAAN" value="<?php echo e($lhp[0]->JUDUL_PEMERIKSAAN); ?>"><br>
			Anggaran: <input type="text" class="form-control" name="ANGGARAN" value="<?php echo e($lhp[0]->ANGGARAN); ?>"><br>
			Upload file :
			<div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">File <span class="required">*</span></label>
			<!-- <div class="col-md-6 col-sm-6 col-xs-12"> -->

				<input type='file' name='file' class="form-control">

				<!-- <?php if($errors->has('file')): ?>
				<span class="errormsg text-danger"><?php echo e($errors->first('file')); ?></span>
				<?php endif; ?> -->
			<!-- </div> -->
			</div>
			<br>
            
        <br><br>
        <button type="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
	<!-- /.card-body -->
	
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/LHP/edit_lhp.blade.php ENDPATH**/ ?>