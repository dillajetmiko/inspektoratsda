

<?php $__env->startSection("page_title","TEMUAN"); ?>

<?php $__env->startSection("title","TEMUAN"); ?>

<?php $__env->startSection("breadcrumb"); ?>
<li class="breadcrumb-item"><a href="dashboard">Home</a></li>
<li class="breadcrumb-item active">Temuan</li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="card">    
  <div class="card-header">
	  <h3 class="card-title"> DATA TEMUAN</h3>
	  <div class="card-tools">
		  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
			<i class="fas fa-minus"></i></button>
		  <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
			<i class="fas fa-times"></i></button>
	  </div>
  </div>
  <div class="card-body">
		<div class="card">
			<div class="card-header">
			<!-- <h3 class="card-title">Tambah Data Anggota</h3> -->
				<div class="row">
					<div class="col-md-9">
						<div class="form-group">
							<form action="/temuan/cari" method="GET">
							<!-- <input type="text" name="cari" placeholder="Cari Pegawai .." value="<?php echo e(old('cari')); ?>">
							<input type="submit" value="CARI"> -->
							<div class="input-group">
								<div style="width: 20%">
									<select class="form-control" name="cari">
										<option value="0">-Pilih Jenis-</option>
										<option value="1">Internal</option>
										<option value="2">Eksternal</option>
									</select>
								</div>
								<!-- <div style="width: 42%">
									<select class="form-control select2" name="KODE_OPD">
										<option value="0">-Pilih OPD-</option>
										<?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($opd->KODE_OPD); ?>"><?php echo e($opd->NAMA_OPD); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div style="width: 20%">
									<select class="form-control select2" name="year">
										<option value="0">-Pilih Tahun-</option>
										<?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div> -->
								<div class="input-group-append">
									<span><input type="submit" class="btn btn-default" value="CARI"></span>
								</div>
							</div>
							</form>
						</div>
					</div>
					<div class="col-md-3">
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tambah-temuan')): ?>
						<a href="/temuan/insert_temuan">
						<button type="button" class="btn btn-info float-right" style="float: right;"><i class="fas fa-plus"></i>  Tambah Data Temuan</button>
						</a>
						<?php endif; ?>
					</div>
				</div>
				
			</div>
			<!-- /.card-header -->
			<div class="card-body">
			<table id="example1" class="table table-bordered table-striped">
				<thead>
				<tr>		
					<th rowspan="2" scope="rowgroup" style="text-align:center">id</th>
					<th rowspan="2" scope="rowgroup" style="text-align:center">Nomer LHP</th>
					<th colspan="2" scope="colgroup" style="text-align:center">Temuan</th>
					<th colspan="1" scope="colgroup" style="text-align:center">Rekomendasi</th>
					<th colspan="1" scope="colgroup" style="text-align:center">Tindak Lanjut</th>
					<th rowspan="2" scope="rowgroup" style="text-align:center">Kerugian</th>
					<th rowspan="2" scope="rowgroup" style="text-align:center">Jenis Temuan</th>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-temuan')): ?>
					<th rowspan="2" scope="rowgroup" style="text-align:center" width="15%">Aksi</th>
					<?php endif; ?>
				</tr>
				<tr>
					<th style="text-align:center">Kode</th>
					<th style="text-align:center">Uraian</th>
					<th style="text-align:center">Kode/Uraian</th>
					<th style="text-align:center">Tanggal/Uraian/Status</th>
				</tr>
				</thead>
				<tbody>		
				<?php $__currentLoopData = $temuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($data->id); ?></td>
					<td><?php echo e($data->NOMOR_LHP); ?></td>
					<td><?php echo e($data->ID_KATEGORI); ?></td>
					<td><?php echo e($data->URAIAN_TEMUAN); ?></td>	
					<td>
						<table>
							<?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($rekom->ID_TEMUAN === $data->id): ?>
							<tr>
								<td><?php echo e($rekom->KODE_REKOMENDASI); ?><br></td>
								<td><?php echo e($rekom->URAIAN_REKOMENDASI); ?></td>
							</tr>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
						<a href='/rekomendasi/insert_view_rekomendasi/<?php echo e($data->id); ?>'>
                        Lihat Detail
                        </a>
					</td>
					<td>
						<table>
							<?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($rekom->ID_TEMUAN === $data->id): ?>
							<tr>
								<td><?php echo e($rekom->TANGGAL_TINDAK_LANJUT); ?></td>
								<td><?php echo e($rekom->URAIAN_TINDAK_LANJUT); ?><br></td>
								<td><?php echo e($rekom->STATUS); ?><br></td>
							</tr>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</td>	
					<td><?php echo e($data->KERUGIAN); ?></td>
					<?php if($data->KODE_JENIS_TEMUAN == 1): ?>
					<td> Internal</td> 
					<?php elseif($data->KODE_JENIS_TEMUAN == 2): ?>
					<td> Eksternal</td>
					<?php endif; ?>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-temuan')): ?>
					<td><a href='/temuan/edit_temuan/<?php echo e($data->id); ?>'>
					<button type="button" class="btn btn-primary"><i class="fas fa-edit"></i> Edit</button>
					</a>
					<!-- <a href='/temuan/hapus/<?php echo e($data->id); ?>'>
					<button type="button" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</button>
					</a> -->
					<button onclick="confirmDelete('<?php echo e($data->id); ?>')" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</button>
					</td> 
					<?php endif; ?>
                     
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<tfoot>
				<!-- <tr>
				<th>NIS_NIP</th>
				<th>nama_anggota</th>
				<th>tahun_masuk</th>
				<th>kelas</th>
				<th>username_anggota</th>
				<th>password_anggota</th>
				</tr> -->
				</tfoot>
			</table>
			</div>
			<!-- /.card-body -->
		</div>
		<!-- /.card -->
  </div>
  <!-- /.card-body -->
  <div class="card-footer">
	<!-- <a href="/LHP/insert_lhp"><b>Tambah Data LHP</b></a> -->
  </div>
  <!-- /.card-footer-->
</div>
<!-- /.card -->

 
<div class="modal fade" id="deleteTemuan" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Hapus Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
      </div>
      <div class="modal-body">
        Apakah anda yakin ingin menghapus data ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
		<a id="deleteLink">
		<button type="button" class="btn btn-danger">Hapus</button>
		</a>
	</div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset ('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset ('asset/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
  $(function () {
	$("#example1").DataTable({
	  "responsive": true,
	  "autoWidth": false,
	});

	//Initialize Select2 Elements
    $('.select2').select2()

  });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	function confirmDelete(id)
	{
		var link = document.getElementById('deleteLink')
		link.href="/temuan/hapus/" + id
		$('#deleteTemuan').modal('show')
	}


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.mainlayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/temuan/view_temuan.blade.php ENDPATH**/ ?>