

<?php $__env->startSection('page_title', 'Inspektorat || Edit Rekomendasi'); ?>

<?php $__env->startSection('title', 'Data Rekomendasi'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/temuan">Temuan</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>  
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Data Rekomendasi</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/rekomendasi/update_rekomendasi" method="post">
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

            id Temuan : <input type="text" class="form-control" name="ID_TEMUAN" value="<?php echo e($rekomendasi[0]->ID_TEMUAN); ?>" readonly><br>
            id Rekomendasi : <input type="text" class="form-control" name="id" value="<?php echo e($rekomendasi[0]->id); ?>" readonly><br>
            Kode Rekomedasi : <input type="text" class="form-control" name="KODE_REKOMENDASI" value="<?php echo e($rekomendasi[0]->KODE_REKOMENDASI); ?>"><br>
            Uraian Rekomendasi : <textarea type="text" class="form-control" name="URAIAN_REKOMENDASI"><?php echo e($rekomendasi[0]->URAIAN_REKOMENDASI); ?></textarea><br>
            Uraian Tindak Lanjut :  <textarea type="text" class="form-control" name="URAIAN_TINDAK_LANJUT"><?php echo e($rekomendasi[0]->URAIAN_TINDAK_LANJUT); ?></textarea><br>
            Status Tindak Lanjut :<br>
                <?php if($rekomendasi[0]->ID_STATUS == 1): ?> 
                <label><input type="radio" name="ID_STATUS" value="1" checked="checked"/> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="ID_STATUS" value="2" /> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="ID_STATUS" value="3" /> Sesuai Rekomendasi </label><br>
                <?php elseif($rekomendasi[0]->ID_STATUS == 2): ?>
                <label><input type="radio" name="ID_STATUS" value="1" /> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="ID_STATUS" value="2" checked="checked"/> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="ID_STATUS" value="3" /> Sesuai Rekomendasi </label><br>
                <?php elseif($rekomendasi[0]->ID_STATUS == 3): ?>
                <label><input type="radio" name="ID_STATUS" value="1" /> Belum Ditindak Lanjut </label><br>
                <label><input type="radio" name="ID_STATUS" value="2" /> Belum Sesuai Rekomendasi </label><br>
                <label><input type="radio" name="ID_STATUS" value="3" checked="checked"/> Sesuai Rekomendasi </label><br>
                <?php endif; ?>
                <br>

            Tanggal Tindak Lanjut : <input type="date" class="form-control" name="TANGGAL_TINDAK_LANJUT" value="<?php echo e($rekomendasi[0]->TANGGAL_TINDAK_LANJUT); ?>"><br>
            Hasil Telaah Tindak Lanjut: <textarea type="text" class="form-control" name="HASIL_TELAAH_TINDAK_LANJUT"><?php echo e($rekomendasi[0]->HASIL_TELAAH_TINDAK_LANJUT); ?></textarea><br>

            <button type="submit" class="btn btn-primary">Update</button>
			</form>
	</div>
	<!-- /.card-body -->
	<div class="card-footer">
	
	</div>
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset ('asset/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
  $(function () {

    //Initialize Select2 Elements
    $('.select2').select2()

  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/rekomendasi/edit_rekomendasi.blade.php ENDPATH**/ ?>