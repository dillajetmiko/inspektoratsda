

<?php $__env->startSection('page_title', 'Inspektorat || Edit Kepegawaian'); ?>

<?php $__env->startSection('title', 'Data Kepegawaian'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/pegawai">Kepegawaian</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Data Pegawai</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/pegawai/update_pegawai" method="post">  
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

			</select><br>
			NIK Pegawai : <input type="text" class="form-control" name="NIK_PEGAWAI" value="<?php echo e($pegawai[0]->NIK_PEGAWAI); ?>" readonly><br>
			Nama Pegawai : <input type="text" class="form-control" name="NAMA_PEGAWAI" value="<?php echo e($pegawai[0]->NAMA_PEGAWAI); ?>"><br>
			Alamat : <input type="text" class="form-control" name="ALAMAT_PEGAWAI" value="<?php echo e($pegawai[0]->ALAMAT_PEGAWAI); ?>"><br>
			Tempat, Tanggal Lahir : <input type="text" class="form-control" name="TTL_PEGAWAI" value="<?php echo e($pegawai[0]->TTL_PEGAWAI); ?>"><br>
			NIP Pegawai : <input type="text" class="form-control" name="NIP_PEGAWAI" value="<?php echo e($pegawai[0]->NIP_PEGAWAI); ?>"><br>
			No. Kartu Pegawai : <input type="text" class="form-control" name="NO_KARTU_PEGAWAI" value="<?php echo e($pegawai[0]->NO_KARTU_PEGAWAI); ?>"><br>
			No. Kartu Suami/istri : <input type="text" class="form-control" name="NO_KARTU_SUAMI_ISTRI" value="<?php echo e($pegawai[0]->NO_KARTU_SUAMI_ISTRI); ?>"><br>
            Nomor Taspen : <input type="text" class="form-control" name="NO_TASPEN" value="<?php echo e($pegawai[0]->NO_TASPEN); ?>"><br>
            Nomor Telepon : <input type="text" class="form-control" name="NO_HP" value="<?php echo e($pegawai[0]->NO_HP); ?>"><br>	
            Keluarga : <input type="text" class="form-control" name="KELUARGA" value="<?php echo e($pegawai[0]->KELUARGA); ?>"><br>
            Unit Kerja : <input type="text" class="form-control" name="UNIT_KERJA_PEGAWAI" value="<?php echo e($pegawai[0]->UNIT_KERJA_PEGAWAI); ?>"><br>

            
        <br><br>
        <button type="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
	<!-- /.card-body -->
	
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/pegawai/edit_pegawai.blade.php ENDPATH**/ ?>