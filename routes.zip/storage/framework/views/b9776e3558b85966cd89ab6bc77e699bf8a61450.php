

<?php $__env->startSection("page_title","Jabatan"); ?>

<?php $__env->startSection("title","Data Jabatan"); ?>

<?php $__env->startSection("breadcrumb"); ?>
<li class="breadcrumb-item"><a href="dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/pegawai">Pegawai</a></li>
<li class="breadcrumb-item active">Jabatan</li> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset ('asset/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset ('asset/dist/css/adminlte.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
<div class="card">    
  <div class="card-header">
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-pegawai')): ?>
	  <h3 class="card-title"> Tambah Jabatan</h3>
	  <?php endif; ?>
	  <div class="card-tools">
		  <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
			<i class="fas fa-minus"></i></button>
		  <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
			<i class="fas fa-times"></i></button>
	  </div>
  </div>
  <div class="card-body">
		<div class="card">
		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-pegawai')): ?>
			<div class="card-header">
				<div class="form-group">
					<form action="/jabatan/insert_view_jabatan" method="post" enctype="multipart/form-data">
					<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
					NIK Pegawai : <input type="text" class="form-control" name="NIK_PEGAWAI" value="<?php echo e($pegawai[0]->NIK_PEGAWAI); ?>" readonly><br>
					Nama Pegawai : <input type="text" class="form-control" name="NAMA_PEGAWAI" value="<?php echo e($pegawai[0]->NAMA_PEGAWAI); ?>" readonly><br>
					TMT Jabatan : <input type="date" class="form-control" name="TMT_JABATAN"><br>
					Nama Jabatan : <input type="text" class="form-control" name="NAMA_JABATAN"><br>

					<button type="submit" class="btn btn-primary">Simpan</button>
					<a href='/pangkat/insert_view_pangkat/<?php echo e($pegawai[0]->NIK_PEGAWAI); ?>'>
					<button type="button" class="btn btn-info">Selesai</button>
					</a>
					</form>
				</div>
			</div>
			<?php endif; ?>

			<!-- /.card-header -->
			<div class="card-body">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>
						<th style="text-align:center">TMT Jabatan</th>
						<th style="text-align:center">Nama Jabatan</th>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-pegawai')): ?>
						<th style="text-align:center" width="15%">Aksi</th>
						<?php endif; ?>
					</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td><?php echo e($data->TMT_JABATAN); ?></td>
					<td><?php echo e($data->NAMA_JABATAN); ?></td>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-hapus-pegawai')): ?>
					<td>
					<a href='/jabatan/hapus/<?php echo e($data->ID_JABATAN); ?>&<?php echo e($data->NIK_PEGAWAI); ?>'>
					<button type="button" class="btn btn-danger"><i class="fas fa-trash"></i> Hapus</button>
					</a>
					</td>
					<?php endif; ?>             
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
					</tfoot>
				</table>
			</div>
			<!-- /.card-body -->
		</div>
		<!-- /.card -->
  </div>
  <!-- /.card-body -->
  <div class="card-footer">
	<!-- <a href="/LHP/insert_lhp"><b>Tambah Data LHP</b></a> -->
  </div>
  <!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_script'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset ('asset/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset ('asset/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset ('asset/plugins/select2/js/select2.full.min.js')); ?>"></script>

<script>
  $(function () {
	$("#example1").DataTable({
	  "responsive": true,
	  "autoWidth": false,
	});
	
    //Initialize Select2 Elements
    $('.select2').select2()

  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.mainlayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/jabatan/insert_view_jabatan.blade.php ENDPATH**/ ?>