<head>
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>
<table>
				<?php $__currentLoopData = $lhp2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datalhp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Judul Pemeriksaan</th>
					<td>: <?php echo e($datalhp->JUDUL_PEMERIKSAAN); ?></td>
				</tr>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Tanggal LHP</th>
					<td>: <?php echo e($datalhp->TANGGAL_LHP); ?></td>
				</tr>
				<tr>
					<th colspan="2" scope="colgroup" style="font-weight: bold">Nomor LHP</th>
					<td>: <?php echo e($datalhp->NOMOR_LHP); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>

				<table id="example1" class="table table-bordered table-striped">
					<thead>
					<tr>		
						<th colspan="2" scope="colgroup" style="text-align:center; font-weight: bold; border: 1px solid black">Temuan</th>
						<th colspan="2" scope="colgroup" style="text-align:center; font-weight: bold; border: 1px solid black">Rekomendasi</th>
						<th colspan="3" scope="colgroup" style="text-align:center; font-weight: bold; border: 1px solid black">Tindak Lanjut</th>
						<th rowspan="2" scope="rowgroup" style="text-align:center; font-weight: bold; border: 1px solid black; width: 15px">OPD</th>
						<th rowspan="2" scope="rowgroup" style="text-align:center; font-weight: bold; border: 1px solid black">Kerugian</th>
					</tr>
					<tr>
						<th style="text-align:center; font-weight: bold; border: 1px solid black">Kode</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black; width: 25px">Uraian</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black">Kode</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black; width: 60px">Uraian</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black; width: 11px">Tanggal</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black; width: 40px">Uraian</th>
						<th style="text-align:center; font-weight: bold; border: 1px solid black; width: 15px">Status</th>
					</tr>
					</thead>
					<tbody>		
					<?php $__currentLoopData = $cetak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="border: 1px solid black;"><?php echo e($data->ID_KATEGORI); ?><br></td>
						<td style="border: 1px solid black;"><?php echo e($data->URAIAN_TEMUAN); ?><br></td>
						<td style="border: 1px solid black;"><?php echo e($data->KODE_REKOMENDASI); ?><br></td>
						<td style="border: 1px solid black;"><?php echo e($data->URAIAN_REKOMENDASI); ?><br></td>	
						<td style="border: 1px solid black;"><?php echo e($data->TANGGAL_TINDAK_LANJUT); ?><br></td>	
						<td style="border: 1px solid black;"><?php echo e($data->URAIAN_TINDAK_LANJUT); ?><br></td>	
						<td style="border: 1px solid black;">
						<?php if($data->ID_STATUS == 1): ?>
						Belum Ditindak Lanjut<br>
						<?php elseif($data->ID_STATUS == 2): ?>
						Belum Sesuai Rekomendasi<br>
						<?php elseif($data->ID_STATUS == 3): ?>
						Sesuai Rekomendasi<br>
						<?php endif; ?>
						<td style="border: 1px solid black;">
						<?php $__currentLoopData = $punya_opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($po->ID_REKOMENDASI === $data->idrekom): ?>
								<?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($o->KODE_OPD === $po->KODE_OPD): ?>
								<?php echo e($o->NAMA_OPD); ?><br>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>  
						<td style="border: 1px solid black;"><?php echo e($data->KERUGIAN); ?><br></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
					</tfoot>
				</table>
</body><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/cetak/cetak_view.blade.php ENDPATH**/ ?>