<!-- Sidebar -->
<div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('asset/dist/img/default-user-imge.jpeg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e($nama); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

          <li class="nav-item">
          <?php if($menu == 'dashboard'): ?>
            <a href="/dashboard" class="nav-link active">
          <?php else: ?>
            <a href="/dashboard" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
              Dashboard
              </p>
            </a>
          </li>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-menu')): ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-user')): ?>
          <li class="nav-item">
          <?php if($menu == 'user'): ?>
            <a href="/user" class="nav-link active">
          <?php else: ?>
            <a href="/user" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-user"></i>
              <p>
              User
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-user')): ?>
          <li class="nav-item">
          <?php if($menu == 'opd'): ?>
            <a href="/opd" class="nav-link active">
          <?php else: ?>
            <a href="/opd" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-file"></i>
              <p>
              OPD
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-user')): ?>
          <li class="nav-item">
          <?php if($menu == 'tugas'): ?>
            <a href="/tugas" class="nav-link active">
          <?php else: ?>
            <a href="/tugas" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-file"></i>
              <p>
              Tugas SPT
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-user')): ?>
          <li class="nav-item">
          <?php if($menu == 'jenis_pengawasan'): ?>
            <a href="/jenis_pengawasan" class="nav-link active">
          <?php else: ?>
            <a href="/jenis_pengawasan" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-file"></i>
              <p>
              Jenis Pengawasan
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-pegawai')): ?>
          <li class="nav-item">
          <?php if($menu == 'pegawai'): ?>
            <a href="/pegawai" class="nav-link active">
          <?php else: ?>
            <a href="/pegawai" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-users"></i>
              <p>
              Pegawai
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-spt')): ?>
          <li class="nav-item">
          <?php if($menu == 'spt'): ?>
            <a href="/spt" class="nav-link active">
          <?php else: ?>
            <a href="/spt" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-envelope-open-text"></i>
              <p>
              SPT
              </p>
            </a>
          </li>

          <li class="nav-item">
          <?php if($menu == 'penugasanspt'): ?>
            <a href="/penugasan_spt" class="nav-link active">
          <?php else: ?>
            <a href="/penugasan_spt" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-envelope-open-text"></i>
              <p>
              Penugasan SPT
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-lhp')): ?>
          <li class="nav-item">
          <?php if($menu == 'lhp'): ?>
            <a href="/lhp" class="nav-link active">
          <?php else: ?>
            <a href="/lhp" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-file-alt"></i>
              <p>
              LHP
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-temuan')): ?>
          <li class="nav-item">
          <?php if($menu == 'temuan'): ?>
            <a href="/temuan" class="nav-link active">
          <?php else: ?>
            <a href="/temuan" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-search"></i>
              <p>
              Temuan
              </p>
            </a>
          </li>
          <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-cetak')): ?>
          <li class="nav-item">
          <?php if($menu == 'cetak'): ?>
            <a href="/cetak" class="nav-link active">
          <?php else: ?>
            <a href="/cetak" class="nav-link">
          <?php endif; ?>
              <i class="nav-icon fas fa-print"></i>
              <p>
              Cetak
              </p>
            </a>
          </li>
          <?php endif; ?>

          <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-role')): ?>
          <li class="nav-item">
            <a href="/validasi" class="nav-link">
          
              <i class="nav-icon fas fa-book"></i>
              <p>
              Update Role
              </p>
            </a>
          </li>
          <?php endif; ?> -->

        <?php endif; ?>
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar --><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>