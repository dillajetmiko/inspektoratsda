

<?php $__env->startSection('page_title', 'Inspektorat || Edit USER'); ?>

<?php $__env->startSection('title', 'Data USER'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/user">User</a></li>
<li class="breadcrumb-item active">Update Data</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Data User</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/user/update_user" method="post">  
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

			</select><br>
			NIP : <input type="text" class="form-control" name="NIP" value="<?php echo e($user[0]->NIP); ?>" readonly><br>
            Nama : <input type="text" class="form-control" name="NAMA" value="<?php echo e($user[0]->name); ?>"><br>
			Email : <input type="text" class="form-control" name="EMAIL" value="<?php echo e($user[0]->email); ?>"><br>
            Password : <input type="password" class="form-control" name="PASSWORD" placeholder="isi jika merubah password"><br>
			Role :<br>
				<select class="form-control select2" name="id_role">
                <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($ro->id_role === $user[0]->id_role): ?>
                <option value="<?php echo e($ro->id_role); ?>" selected><?php echo e($ro->nama_role); ?></option>
                <?php else: ?>
                <option value="<?php echo e($ro->id_role); ?>"><?php echo e($ro->nama_role); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
			Jabatan: <input type="text" class="form-control" name="JABATAN" value="<?php echo e($user[0]->jabatan); ?>"><br>
            Pangkat: <input type="text" class="form-control" name="PANGKAT" value="<?php echo e($user[0]->pangkat); ?>"><br>
            
        <br><br>
        <button type="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
	<!-- /.card-body -->
	
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/user/edit_user.blade.php ENDPATH**/ ?>