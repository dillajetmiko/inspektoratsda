

<?php $__env->startSection('page_title', 'Inspektorat || Edit Tugas SPT'); ?>

<?php $__env->startSection('title', 'Data Tugas SPT'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
<li class="breadcrumb-item"><a href="/tugas">Tugas SPT</a></li>
<li class="breadcrumb-item active">Update Tugas SPT</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Default box -->
<div class="card">
	<div class="card-header">
		<h3 class="card-title">Edit Tugas SPT</h3>

		<div class="card-tools">
			<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				<i class="fas fa-minus"></i></button>
			<button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				<i class="fas fa-times"></i></button>
		</div>
	</div>
	<div class="card-body">

		<form action="/tugas/update_tugas" method="post">  
			<input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">

			</select><br>
			ID Tugas : <input type="text" class="form-control" name="ID_TUGAS" value="<?php echo e($tugas[0]->ID_TUGAS); ?>" readonly><br>
			Nama Tugas : <input type="text" class="form-control" name="NAMA_TUGAS" value="<?php echo e($tugas[0]->NAMA_TUGAS); ?>"><br>
			Urutan : <input type="text" class="form-control" name="urutan" value="<?php echo e($tugas[0]->urutan); ?>"><br>

			<button type="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
	<!-- /.card-body -->
	
	<!-- /.card-footer-->
</div>
<!-- /.card -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inspektoratsda\resources\views/tugas/edit_tugas.blade.php ENDPATH**/ ?>